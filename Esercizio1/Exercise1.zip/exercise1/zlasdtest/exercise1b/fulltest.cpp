
#include <iostream>

/* ************************************************************************** */

void testFullExercise1B(uint&, uint&) {
}
