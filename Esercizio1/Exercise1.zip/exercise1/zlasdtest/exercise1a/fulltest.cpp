
#include <iostream>

/* ************************************************************************** */

void testFullExercise1A(uint&, uint&) {
}
