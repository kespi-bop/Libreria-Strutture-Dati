
#include <iostream>

/* ************************************************************************** */

void testFullExercise3(uint& testnum, uint& testerr) {
}
